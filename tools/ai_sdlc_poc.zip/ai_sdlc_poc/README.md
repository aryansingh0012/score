# Harbor AI-SDLC PoC

This package is the first executable slice of the lifecycle PoC. Harbor is the
evaluation and reporting layer; the workflow records the artifacts that the
real SpecKit and Microsoft APM executions must provide.

The offline replay uses the lifecycle task from issue #439, compares against
PR #444 as ground truth, runs sequential and concurrent paths, and deliberately
introduces the `serviceWatchdog()` run-cycle requirement to exercise impact
analysis and re-planning.

Run from the lifecycle repository root:

```powershell
python -m tools.ai_sdlc_poc --output artifacts/harbor-report.json
python -m tools.ai_sdlc_poc --mode live --output artifacts/harbor-report-live-plan.json
python -m tools.ai_sdlc_poc --mode live --execute-live --output artifacts/harbor-report-live-exec.json
python -m pytest tools/ai_sdlc_poc/test_workflow.py
```

The live-tool phase will replace the recorded SpecKit and APM fixture fields
with outputs from pinned `specify` and `apm` commands. The adapter remains
responsible for orchestration evidence, not for reimplementing either tool.

Pinned tool versions are recorded in `tools/ai_sdlc_poc/tooling.lock.json`.

If you need to bootstrap SpecKit locally for this lifecycle harness, use the
version pinned in `tools/ai_sdlc_poc/tooling.lock.json`:

```powershell
.\tools\ai_sdlc_poc\scripts\install_speckit.ps1
```

Evidence bundles are written under `tools/ai_sdlc_poc/evidence/`:

- `dr009/` contains APM-focused context packaging outputs.
- `dr010/` contains orchestration and lifecycle-flow outputs.
- Live step outputs are captured in `dr009/apm-steps.json` and
	`dr010/speckit-steps.json`.
- DR-010 writes both `impact-analysis.json`/`revalidation.json` and the
	compatibility names `impact.json`/`validation.json`.
